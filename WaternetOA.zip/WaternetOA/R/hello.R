#' Prints 'Hello, world!'
#' @export
hello <- function() {
  print("Hello, world!")
}
